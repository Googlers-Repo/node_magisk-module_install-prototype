const info = (msg) => {
  console.log("- " + msg);
};

const error = (msg) => {
  console.log("! " + msg);
};

const warn = (msg) => {
  console.log("? " + msg);
};
